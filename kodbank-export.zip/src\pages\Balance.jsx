import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import confetti from 'canvas-confetti';

const Balance = () => {
    const [balance, setBalance] = useState(null);
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [revealed, setRevealed] = useState(false);
    const navigate = useNavigate();

    const fireConfetti = () => {
        const count = 250;
        const defaults = { origin: { y: 0.7 }, zIndex: 9999 };

        function fire(particleRatio, opts) {
            confetti({
                ...defaults,
                particleCount: Math.floor(count * particleRatio),
                spread: 30 + 70 * particleRatio,
                startVelocity: 35,
                colors: ['#ff2d2d', '#ffd700', '#00e5ff', '#ff4081', '#ffffff'],
                ...opts,
            });
        }

        fire(0.25, { spread: 26, startVelocity: 55 });
        fire(0.2, { spread: 60 });
        fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
        fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
        fire(0.1, { spread: 120, startVelocity: 45 });
    };

    const fetchBalance = async () => {
        setLoading(true);
        setRevealed(false);
        try {
            const res = await axios.get('/api/balance', { withCredentials: true });
            setBalance(res.data.data.balance);
            setUserData(res.data.data);
            setRevealed(true);
            toast.success('Treasure vault opened!');
            setTimeout(() => fireConfetti(), 300);
        } catch (err) {
            if (err.response?.status === 401) {
                toast.error('Session expired. Return to the gate!');
                navigate('/login');
            } else {
                toast.error(
                    err.response?.data?.message ||
                    (err.code === 'ERR_NETWORK'
                        ? 'Server unreachable! Start the backend first.'
                        : 'Failed to fetch balance.')
                );
            }
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0,
        }).format(amount);
    };

    return (
        <div className="page-container" style={{ justifyContent: 'center' }}>
            <div style={{ maxWidth: '540px', width: '100%', textAlign: 'center' }}>

                {/* Header */}
                <div className="animate-fade-in-up" style={{ marginBottom: '2rem' }}>
                    <h1
                        className="manga-heading"
                        style={{
                            fontSize: 'clamp(1.8rem, 5vw, 2.5rem)',
                            marginBottom: '0.5rem',
                        }}
                    >
                        Treasure <span style={{ color: '#ffd700' }}>Vault</span>
                    </h1>
                    <p style={{ color: '#6a6a80', fontSize: '0.95rem', fontFamily: "'Outfit', sans-serif" }}>
                        Securely reveal your gold reserves
                    </p>
                </div>

                {/* Balance Card */}
                <div
                    className={`balance-card animate-fade-in-up delay-100 ${revealed ? 'animate-pulse-gold' : ''
                        }`}
                    style={{ marginBottom: '1.5rem' }}
                >
                    {!revealed ? (
                        <div style={{ padding: '1.5rem 0' }}>
                            <div
                                style={{
                                    fontSize: '4rem',
                                    marginBottom: '1.25rem',
                                    filter: 'drop-shadow(3px 3px 0 rgba(0,0,0,0.5))',
                                }}
                            >
                                🏯
                            </div>
                            <p
                                className="manga-subheading"
                                style={{
                                    color: '#b0b0c0',
                                    fontSize: '1.1rem',
                                    marginBottom: '1.5rem',
                                }}
                            >
                                Your vault is sealed. Break the seal!
                            </p>
                            <button
                                className="btn-manga-gold"
                                onClick={fetchBalance}
                                disabled={loading}
                                style={{ padding: '16px 44px', fontSize: '1.2rem' }}
                            >
                                {loading ? (
                                    <span
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: '10px',
                                        }}
                                    >
                                        <span
                                            className="loader-spinner"
                                            style={{
                                                width: '20px',
                                                height: '20px',
                                                borderWidth: '3px',
                                                borderTopColor: '#1a1a00',
                                                borderColor: 'rgba(0,0,0,0.2)',
                                            }}
                                        ></span>
                                        Unsealing...
                                    </span>
                                ) : (
                                    '⚡ REVEAL BALANCE!'
                                )}
                            </button>
                        </div>
                    ) : (
                        <div className="animate-count-up">
                            <p className="fx-text" style={{ marginBottom: '0.5rem', fontSize: '0.75rem' }}>
                                ★ AVAILABLE GOLD ★
                            </p>
                            <p
                                className="manga-heading"
                                style={{
                                    fontSize: 'clamp(2.5rem, 7vw, 4rem)',
                                    color: '#ffd700',
                                    textShadow: '4px 4px 0px rgba(0,0,0,0.6), 0 0 30px rgba(255, 215, 0, 0.2)',
                                    lineHeight: '1.1',
                                    marginBottom: '1rem',
                                }}
                            >
                                {formatCurrency(balance)}
                            </p>

                            {/* Details Grid */}
                            <div
                                style={{
                                    display: 'grid',
                                    gridTemplateColumns: '1fr 1fr',
                                    gap: '1rem',
                                    marginTop: '1.5rem',
                                    paddingTop: '1.5rem',
                                    borderTop: '2px solid rgba(255, 45, 45, 0.15)',
                                }}
                            >
                                <DetailItem label="Hero Name" value={userData?.username} />
                                <DetailItem label="Contact Scroll" value={userData?.email} />
                                <DetailItem label="Rank" value={userData?.role} />
                                <DetailItem
                                    label="Hero ID"
                                    value={userData?.uid?.substring(0, 8) + '...'}
                                />
                            </div>

                            <div
                                style={{
                                    display: 'flex',
                                    gap: '0.75rem',
                                    marginTop: '1.5rem',
                                    justifyContent: 'center',
                                    flexWrap: 'wrap',
                                }}
                            >
                                <button
                                    className="btn-manga-outline"
                                    onClick={fetchBalance}
                                    style={{ padding: '10px 22px', fontSize: '0.95rem' }}
                                >
                                    ↻ Refresh
                                </button>
                                <button
                                    className="btn-manga"
                                    onClick={() => navigate('/dashboard')}
                                    style={{ padding: '10px 22px', fontSize: '0.95rem' }}
                                >
                                    ← HQ
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                {/* Security Notice */}
                <div
                    className="animate-fade-in-up delay-300"
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        color: '#4a4a60',
                        fontSize: '0.8rem',
                        fontFamily: "'Outfit', sans-serif",
                    }}
                >
                    <span>🛡️</span>
                    <span>Protected by JWT seal & token verification jutsu</span>
                </div>
            </div>
        </div>
    );
};

const DetailItem = ({ label, value }) => (
    <div style={{ textAlign: 'left' }}>
        <p className="fx-text" style={{ marginBottom: '2px', fontSize: '0.65rem' }}>
            {label}
        </p>
        <p
            style={{
                color: '#d0d0e0',
                fontSize: '0.9rem',
                fontWeight: '500',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                fontFamily: "'Outfit', sans-serif",
            }}
        >
            {value}
        </p>
    </div>
);

export default Balance;
