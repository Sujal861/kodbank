import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const Login = () => {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({ email: '', password: '' });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (!formData.email || !formData.password) {
            setError('All fields required!');
            toast.error('Please fill in all fields');
            return;
        }

        setLoading(true);
        try {
            const res = await axios.post(
                '/api/login',
                { email: formData.email, password: formData.password },
                { withCredentials: true }
            );

            login(res.data.user);
            toast.success(res.data.message || 'Welcome back, hero!');
            navigate('/dashboard');
        } catch (err) {
            const message =
                err.response?.data?.message ||
                (err.code === 'ERR_NETWORK'
                    ? 'Cannot connect to server. Make sure the backend is running!'
                    : 'Login failed. Try again.');
            setError(message);
            toast.error(message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="page-container" style={{ justifyContent: 'center' }}>
            <div
                className="manga-panel animate-slam"
                style={{
                    maxWidth: '460px',
                    width: '100%',
                    padding: '2.5rem',
                }}
            >
                {/* Header */}
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <div
                        style={{
                            fontSize: '3rem',
                            marginBottom: '0.75rem',
                            filter: 'drop-shadow(3px 3px 0 rgba(0,0,0,0.5))',
                        }}
                    >
                        ⛩️
                    </div>
                    <h1
                        className="manga-heading"
                        style={{
                            fontSize: '2.2rem',
                            color: '#ffffff',
                            marginBottom: '0.5rem',
                        }}
                    >
                        Welcome <span style={{ color: '#ff2d2d' }}>Back</span>
                    </h1>
                    <p
                        style={{
                            color: '#6a6a80',
                            fontSize: '0.9rem',
                            fontFamily: "'Outfit', sans-serif",
                        }}
                    >
                        Enter the Kodbank arena
                    </p>
                </div>

                {/* Error Display */}
                {error && (
                    <div className="error-display">
                        ⚠️ {error}
                    </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '1.25rem' }}>
                        <label className="manga-label" htmlFor="login-email">
                            ✉ Email
                        </label>
                        <input
                            id="login-email"
                            className="manga-input"
                            type="email"
                            name="email"
                            placeholder="hero@kodbank.com"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            autoComplete="email"
                        />
                    </div>

                    <div style={{ marginBottom: '1.75rem' }}>
                        <label className="manga-label" htmlFor="login-password">
                            🔒 Secret Key
                        </label>
                        <input
                            id="login-password"
                            className="manga-input"
                            type="password"
                            name="password"
                            placeholder="Enter your secret key..."
                            value={formData.password}
                            onChange={handleChange}
                            required
                            autoComplete="current-password"
                        />
                    </div>

                    <button
                        type="submit"
                        className="btn-manga"
                        disabled={loading}
                        style={{
                            width: '100%',
                            padding: '16px',
                            fontSize: '1.2rem',
                        }}
                    >
                        {loading ? (
                            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                                <span
                                    className="loader-spinner"
                                    style={{ width: '20px', height: '20px', borderWidth: '3px' }}
                                ></span>
                                Entering...
                            </span>
                        ) : (
                            '⚡ Enter Arena!'
                        )}
                    </button>
                </form>

                {/* Divider */}
                <hr className="manga-divider" />

                {/* Footer */}
                <p
                    style={{
                        textAlign: 'center',
                        color: '#6a6a80',
                        fontSize: '0.9rem',
                        fontFamily: "'Outfit', sans-serif",
                    }}
                >
                    New to the guild?{' '}
                    <Link
                        to="/register"
                        style={{
                            color: '#ffd700',
                            textDecoration: 'none',
                            fontWeight: '700',
                            fontFamily: "'Bangers', cursive",
                            letterSpacing: '0.05em',
                        }}
                    >
                        Register Now!
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default Login;
