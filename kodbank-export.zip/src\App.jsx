import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Balance from './pages/Balance';
import TokenView from './pages/TokenView';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3500,
            style: {
              background: 'rgba(10, 10, 15, 0.97)',
              color: '#ffffff',
              border: '2px solid rgba(255, 45, 45, 0.4)',
              borderRadius: '2px',
              padding: '14px 18px',
              fontSize: '0.95rem',
              fontFamily: "'Outfit', sans-serif",
              fontWeight: '500',
              boxShadow: '4px 4px 0px rgba(255, 45, 45, 0.2), 0 8px 20px rgba(0, 0, 0, 0.5)',
            },
            success: {
              iconTheme: {
                primary: '#ffd700',
                secondary: '#1a1a00',
              },
              style: {
                border: '2px solid rgba(255, 215, 0, 0.4)',
                boxShadow: '4px 4px 0px rgba(255, 215, 0, 0.2), 0 8px 20px rgba(0, 0, 0, 0.5)',
              },
            },
            error: {
              iconTheme: {
                primary: '#ff2d2d',
                secondary: '#ffffff',
              },
              style: {
                border: '2px solid rgba(255, 45, 45, 0.5)',
              },
            },
          }}
        />
        <Navbar />
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/balance"
            element={
              <ProtectedRoute>
                <Balance />
              </ProtectedRoute>
            }
          />
          <Route
            path="/token"
            element={
              <ProtectedRoute>
                <TokenView />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
