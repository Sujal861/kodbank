import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import routes
import authRoutes from './routes/auth.js';
import balanceRoutes from './routes/balance.js';
import tokenRoutes from './routes/token.js';

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(
    cors({
        origin: process.env.CLIENT_URL || 'http://localhost:5173',
        credentials: true,
    })
);

// Routes
app.use('/api', authRoutes);
app.use('/api', balanceRoutes);
app.use('/api', tokenRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        success: false,
        message: 'Internal server error.',
    });
});

// Connect to MongoDB and start server
const startServer = async () => {
    try {
        if (!process.env.MONGO_URI) {
            console.error('ERROR: MONGO_URI is not defined in .env file');
            process.exit(1);
        }

        if (!process.env.JWT_SECRET) {
            console.error('ERROR: JWT_SECRET is not defined in .env file');
            process.exit(1);
        }

        await mongoose.connect(process.env.MONGO_URI);
        console.log('✅ Connected to MongoDB Atlas');

        app.listen(PORT, () => {
            console.log(`🚀 Kodbank server running on http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error('❌ Failed to connect to MongoDB:', error.message);
        process.exit(1);
    }
};

startServer();

export default app;
