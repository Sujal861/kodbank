import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
    const { user, logout, isAuthenticated } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [mobileOpen, setMobileOpen] = useState(false);

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    const isActive = (path) => location.pathname === path;

    return (
        <nav
            style={{
                background: 'rgba(10, 10, 15, 0.95)',
                borderBottom: '3px solid #ff2d2d',
                position: 'sticky',
                top: 0,
                zIndex: 50,
                boxShadow: '0 4px 20px rgba(255, 45, 45, 0.1)',
            }}
        >
            <div
                style={{
                    maxWidth: '1200px',
                    margin: '0 auto',
                    padding: '0 1.5rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    height: '72px',
                }}
            >
                {/* Logo */}
                <Link
                    to={isAuthenticated ? '/dashboard' : '/'}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        textDecoration: 'none',
                    }}
                >
                    <div
                        style={{
                            width: '40px',
                            height: '40px',
                            background: '#ff2d2d',
                            border: '2px solid #cc0000',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white',
                            fontFamily: "'Bangers', cursive",
                            fontWeight: '400',
                            fontSize: '1.2rem',
                            letterSpacing: '0.05em',
                            boxShadow: '3px 3px 0px rgba(0,0,0,0.5)',
                            transform: 'rotate(-3deg)',
                        }}
                    >
                        K
                    </div>
                    <span
                        style={{
                            fontFamily: "'Bangers', cursive",
                            fontSize: '1.6rem',
                            color: '#ffffff',
                            letterSpacing: '0.06em',
                            textShadow: '2px 2px 0px rgba(255, 45, 45, 0.4)',
                            textTransform: 'uppercase',
                        }}
                    >
                        Kod
                        <span style={{ color: '#ff2d2d' }}>bank</span>
                    </span>
                </Link>

                {/* Desktop Nav */}
                <div
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.25rem',
                    }}
                    className="desktop-nav"
                >
                    {isAuthenticated ? (
                        <>
                            <NavLink to="/dashboard" active={isActive('/dashboard')}>
                                Dashboard
                            </NavLink>
                            <NavLink to="/balance" active={isActive('/balance')}>
                                Balance
                            </NavLink>
                            <div
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '12px',
                                    marginLeft: '1rem',
                                    paddingLeft: '1rem',
                                    borderLeft: '2px solid rgba(255, 45, 45, 0.2)',
                                }}
                            >
                                <div
                                    style={{
                                        width: '34px',
                                        height: '34px',
                                        background: 'linear-gradient(135deg, #ff2d2d, #cc0000)',
                                        border: '2px solid #ff4444',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        color: 'white',
                                        fontFamily: "'Bangers', cursive",
                                        fontSize: '1rem',
                                        boxShadow: '2px 2px 0 rgba(0,0,0,0.4)',
                                    }}
                                >
                                    {user?.username?.charAt(0).toUpperCase()}
                                </div>
                                <span
                                    style={{
                                        color: '#b0b0c0',
                                        fontSize: '0.9rem',
                                        fontWeight: '600',
                                        fontFamily: "'Outfit', sans-serif",
                                    }}
                                >
                                    {user?.username}
                                </span>
                                <button
                                    onClick={handleLogout}
                                    style={{
                                        fontFamily: "'Bangers', cursive",
                                        letterSpacing: '0.08em',
                                        textTransform: 'uppercase',
                                        background: 'rgba(255, 45, 45, 0.1)',
                                        color: '#ff4444',
                                        border: '2px solid rgba(255, 45, 45, 0.3)',
                                        padding: '6px 16px',
                                        fontSize: '0.85rem',
                                        cursor: 'pointer',
                                        transition: 'all 0.2s ease',
                                        boxShadow: '2px 2px 0 rgba(0,0,0,0.3)',
                                    }}
                                    onMouseEnter={(e) => {
                                        e.target.style.background = 'rgba(255, 45, 45, 0.2)';
                                        e.target.style.transform = 'translate(-1px, -1px)';
                                        e.target.style.boxShadow = '3px 3px 0 rgba(0,0,0,0.4)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.target.style.background = 'rgba(255, 45, 45, 0.1)';
                                        e.target.style.transform = 'translate(0, 0)';
                                        e.target.style.boxShadow = '2px 2px 0 rgba(0,0,0,0.3)';
                                    }}
                                >
                                    Logout
                                </button>
                            </div>
                        </>
                    ) : (
                        <>
                            <NavLink to="/login" active={isActive('/login')}>
                                Login
                            </NavLink>
                            <Link
                                to="/register"
                                className="btn-manga"
                                style={{
                                    textDecoration: 'none',
                                    padding: '8px 20px',
                                    fontSize: '1rem',
                                    marginLeft: '0.5rem',
                                }}
                            >
                                Register
                            </Link>
                        </>
                    )}
                </div>

                {/* Mobile hamburger */}
                <button
                    className="mobile-menu-btn"
                    onClick={() => setMobileOpen(!mobileOpen)}
                    style={{
                        display: 'none',
                        background: 'none',
                        border: '2px solid #ff2d2d',
                        color: '#ff2d2d',
                        fontSize: '1.3rem',
                        cursor: 'pointer',
                        padding: '4px 8px',
                        fontFamily: "'Bangers', cursive",
                        boxShadow: '2px 2px 0 rgba(0,0,0,0.4)',
                    }}
                >
                    {mobileOpen ? '✕' : '☰'}
                </button>
            </div>

            {/* Mobile Menu */}
            {mobileOpen && (
                <div
                    className="mobile-menu"
                    style={{
                        padding: '1rem 1.5rem 1.5rem',
                        borderTop: '2px solid rgba(255, 45, 45, 0.2)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '0.5rem',
                        background: 'rgba(10, 10, 15, 0.98)',
                    }}
                >
                    {isAuthenticated ? (
                        <>
                            <MobileNavLink to="/dashboard" onClick={() => setMobileOpen(false)}>
                                ⚔️ Dashboard
                            </MobileNavLink>
                            <MobileNavLink to="/balance" onClick={() => setMobileOpen(false)}>
                                💰 Balance
                            </MobileNavLink>
                            <button
                                onClick={() => { setMobileOpen(false); handleLogout(); }}
                                style={{
                                    fontFamily: "'Bangers', cursive",
                                    letterSpacing: '0.08em',
                                    textTransform: 'uppercase',
                                    background: 'rgba(255, 45, 45, 0.1)',
                                    color: '#ff4444',
                                    border: '2px solid rgba(255, 45, 45, 0.3)',
                                    padding: '12px',
                                    cursor: 'pointer',
                                    fontSize: '1rem',
                                    marginTop: '0.5rem',
                                }}
                            >
                                ⛩️ Logout
                            </button>
                        </>
                    ) : (
                        <>
                            <MobileNavLink to="/login" onClick={() => setMobileOpen(false)}>
                                🔑 Login
                            </MobileNavLink>
                            <MobileNavLink to="/register" onClick={() => setMobileOpen(false)}>
                                ✍️ Register
                            </MobileNavLink>
                        </>
                    )}
                </div>
            )}

            <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: block !important; }
        }
        @media (min-width: 769px) {
          .mobile-menu { display: none !important; }
        }
      `}</style>
        </nav>
    );
};

const NavLink = ({ to, children, active }) => (
    <Link
        to={to}
        style={{
            fontFamily: "'Bangers', cursive",
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            color: active ? '#ff2d2d' : '#b0b0c0',
            textDecoration: 'none',
            padding: '8px 14px',
            fontSize: '1rem',
            transition: 'all 0.2s ease',
            borderBottom: active ? '2px solid #ff2d2d' : '2px solid transparent',
            textShadow: active ? '1px 1px 0 rgba(0,0,0,0.5)' : 'none',
        }}
    >
        {children}
    </Link>
);

const MobileNavLink = ({ to, children, onClick }) => (
    <Link
        to={to}
        onClick={onClick}
        style={{
            fontFamily: "'Bangers', cursive",
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            color: '#e0e0e0',
            textDecoration: 'none',
            padding: '12px',
            fontSize: '1.05rem',
            background: 'rgba(255, 45, 45, 0.05)',
            border: '1px solid rgba(255, 45, 45, 0.1)',
        }}
    >
        {children}
    </Link>
);

export default Navbar;
