import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
    const { user } = useAuth();
    const navigate = useNavigate();

    const actions = [
        {
            id: 'check-balance',
            icon: '💰',
            title: 'Check Balance',
            subtitle: 'Power Level: Finance',
            description: 'Reveal your treasure vault and see your current gold reserves',
            color: '#ffd700',
            bgGrad: 'linear-gradient(135deg, rgba(255, 215, 0, 0.08), rgba(255, 170, 0, 0.03))',
            borderColor: 'rgba(255, 215, 0, 0.3)',
            onClick: () => navigate('/balance'),
        },
        {
            id: 'view-token',
            icon: '🔑',
            title: 'View JWT Token',
            subtitle: 'Secret Scroll',
            description: 'Inspect your sacred session scroll and its seal of expiry',
            color: '#00e5ff',
            bgGrad: 'linear-gradient(135deg, rgba(0, 229, 255, 0.08), rgba(0, 180, 255, 0.03))',
            borderColor: 'rgba(0, 229, 255, 0.3)',
            onClick: () => navigate('/token'),
        },
    ];

    return (
        <div className="page-container">
            <div style={{ maxWidth: '820px', width: '100%', margin: '0 auto' }}>

                {/* Welcome Banner */}
                <div
                    className="animate-slam"
                    style={{ marginBottom: '2.5rem', textAlign: 'center' }}
                >
                    <div className="manga-badge" style={{ marginBottom: '1rem' }}>
                        <span
                            style={{
                                width: '8px',
                                height: '8px',
                                borderRadius: '50%',
                                background: '#00ff88',
                                display: 'inline-block',
                                boxShadow: '0 0 6px #00ff88',
                            }}
                        ></span>
                        SESSION ACTIVE — HERO ONLINE
                    </div>

                    <h1
                        className="manga-heading"
                        style={{
                            fontSize: 'clamp(2rem, 5vw, 3rem)',
                            marginBottom: '0.5rem',
                        }}
                    >
                        Welcome,{' '}
                        <span style={{ color: '#ff2d2d' }}>{user?.username}!</span>
                    </h1>
                    <p
                        style={{
                            color: '#6a6a80',
                            fontSize: '1.05rem',
                            fontFamily: "'Outfit', sans-serif",
                            maxWidth: '500px',
                            margin: '0 auto',
                        }}
                    >
                        Your command center is ready. Choose your next move, hero.
                    </p>
                </div>

                {/* Hero Info Card */}
                <div
                    className="manga-glass animate-fade-in-up delay-100"
                    style={{
                        padding: '1.25rem 1.75rem',
                        marginBottom: '2rem',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '1rem',
                        flexWrap: 'wrap',
                    }}
                >
                    <div
                        style={{
                            width: '52px',
                            height: '52px',
                            background: 'linear-gradient(135deg, #ff2d2d, #cc0000)',
                            border: '3px solid #ff4444',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white',
                            fontFamily: "'Bangers', cursive",
                            fontSize: '1.5rem',
                            flexShrink: 0,
                            boxShadow: '3px 3px 0 rgba(0,0,0,0.5)',
                            transform: 'rotate(-2deg)',
                        }}
                    >
                        {user?.username?.charAt(0).toUpperCase()}
                    </div>
                    <div style={{ flex: 1, minWidth: '180px' }}>
                        <p
                            style={{
                                fontFamily: "'Bangers', cursive",
                                fontSize: '1.15rem',
                                letterSpacing: '0.04em',
                                marginBottom: '2px',
                            }}
                        >
                            {user?.username}
                        </p>
                        <p style={{ color: '#6a6a80', fontSize: '0.85rem' }}>
                            {user?.email}
                        </p>
                    </div>
                    <div
                        style={{
                            background: 'rgba(255, 215, 0, 0.1)',
                            border: '2px solid rgba(255, 215, 0, 0.3)',
                            padding: '4px 14px',
                            fontFamily: "'Bangers', cursive",
                            color: '#ffd700',
                            fontSize: '0.85rem',
                            letterSpacing: '0.1em',
                            textTransform: 'uppercase',
                            boxShadow: '2px 2px 0 rgba(0,0,0,0.3)',
                        }}
                    >
                        ★ {user?.role || 'Customer'}
                    </div>
                </div>

                {/* Action Cards */}
                <div
                    style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                        gap: '1.5rem',
                    }}
                >
                    {actions.map((action, idx) => (
                        <button
                            key={action.id}
                            id={action.id}
                            onClick={action.onClick}
                            className={`animate-fade-in-up delay-${(idx + 2) * 100}`}
                            style={{
                                background: action.bgGrad,
                                border: `2px solid ${action.borderColor}`,
                                borderRadius: '4px',
                                padding: '2rem',
                                cursor: 'pointer',
                                textAlign: 'left',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '1rem',
                                transition: 'all 0.2s ease',
                                position: 'relative',
                                overflow: 'hidden',
                                fontFamily: "'Outfit', sans-serif",
                                boxShadow: `4px 4px 0px ${action.borderColor}`,
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.transform = 'translate(-4px, -4px)';
                                e.currentTarget.style.boxShadow = `8px 8px 0px ${action.borderColor}`;
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.transform = 'translate(0, 0)';
                                e.currentTarget.style.boxShadow = `4px 4px 0px ${action.borderColor}`;
                            }}
                        >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                <span style={{ fontSize: '2rem', filter: 'drop-shadow(2px 2px 0 rgba(0,0,0,0.5))' }}>
                                    {action.icon}
                                </span>
                                <div>
                                    <h3
                                        className="manga-subheading"
                                        style={{
                                            fontSize: '1.3rem',
                                            color: '#fff',
                                            marginBottom: '2px',
                                        }}
                                    >
                                        {action.title}
                                    </h3>
                                    <span className="fx-text">{action.subtitle}</span>
                                </div>
                            </div>
                            <p
                                style={{
                                    color: '#8a8a9a',
                                    fontSize: '0.9rem',
                                    lineHeight: '1.5',
                                }}
                            >
                                {action.description}
                            </p>
                            <div
                                style={{
                                    fontFamily: "'Bangers', cursive",
                                    letterSpacing: '0.1em',
                                    color: action.color,
                                    fontSize: '0.9rem',
                                    marginTop: 'auto',
                                    textShadow: '1px 1px 0 rgba(0,0,0,0.5)',
                                }}
                            >
                                ACTIVATE →
                            </div>
                        </button>
                    ))}
                </div>

                {/* Stats Panel */}
                <div
                    className="manga-glass animate-fade-in-up delay-400"
                    style={{
                        marginTop: '2rem',
                        padding: '1.25rem 2rem',
                        display: 'flex',
                        justifyContent: 'space-around',
                        flexWrap: 'wrap',
                        gap: '1rem',
                    }}
                >
                    <StatItem label="Class" value="Savings" />
                    <StatItem label="Rank" value={user?.role || 'Customer'} gold />
                    <StatItem label="Status" value="⚡ Active" green />
                    <StatItem
                        label="Hero ID"
                        value={user?.uid?.substring(0, 8) + '...' || 'N/A'}
                    />
                </div>
            </div>
        </div>
    );
};

const StatItem = ({ label, value, gold, green }) => (
    <div style={{ textAlign: 'center', minWidth: '100px' }}>
        <p className="fx-text" style={{ marginBottom: '4px', fontSize: '0.65rem' }}>
            {label}
        </p>
        <p
            style={{
                color: green ? '#00ff88' : gold ? '#ffd700' : '#fff',
                fontFamily: "'Bangers', cursive",
                fontSize: '1rem',
                letterSpacing: '0.04em',
                textShadow: '1px 1px 0 rgba(0,0,0,0.5)',
            }}
        >
            {value}
        </p>
    </div>
);

export default Dashboard;
