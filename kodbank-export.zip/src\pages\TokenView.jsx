import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';

const TokenView = () => {
    const [tokenData, setTokenData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [showFull, setShowFull] = useState(false);
    const navigate = useNavigate();

    const fetchToken = async () => {
        setLoading(true);
        try {
            const res = await axios.get('/api/token', { withCredentials: true });
            setTokenData(res.data.data);
            toast.success('Secret scroll retrieved!');
        } catch (err) {
            if (err.response?.status === 401) {
                toast.error('Session expired. Return to the gate!');
                navigate('/login');
            } else {
                toast.error(err.response?.data?.message || 'Failed to fetch token.');
            }
        } finally {
            setLoading(false);
        }
    };

    const copyToken = () => {
        if (tokenData?.token) {
            navigator.clipboard.writeText(tokenData.token);
            toast.success('Scroll copied to clipboard!');
        }
    };

    const formatDate = (dateStr) => {
        return new Date(dateStr).toLocaleString('en-IN', {
            dateStyle: 'medium',
            timeStyle: 'short',
        });
    };

    const getTimeRemaining = () => {
        if (!tokenData?.expiry) return null;
        const remaining = new Date(tokenData.expiry) - new Date();
        if (remaining <= 0) return '⚠ EXPIRED';
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        return `${hours}h ${minutes}m`;
    };

    return (
        <div className="page-container" style={{ justifyContent: 'center' }}>
            <div style={{ maxWidth: '580px', width: '100%' }}>

                {/* Header */}
                <div className="animate-fade-in-up" style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <h1
                        className="manga-heading"
                        style={{
                            fontSize: 'clamp(1.8rem, 5vw, 2.5rem)',
                            marginBottom: '0.5rem',
                        }}
                    >
                        Secret <span style={{ color: '#00e5ff' }}>Scroll</span>
                    </h1>
                    <p
                        style={{
                            color: '#6a6a80',
                            fontSize: '0.95rem',
                            fontFamily: "'Outfit', sans-serif",
                        }}
                    >
                        Access your JWT session token
                    </p>
                </div>

                {!tokenData ? (
                    /* Fetch Card */
                    <div
                        className="manga-panel animate-slam"
                        style={{ padding: '3rem 2rem', textAlign: 'center' }}
                    >
                        <div
                            style={{
                                fontSize: '4rem',
                                marginBottom: '1.25rem',
                                filter: 'drop-shadow(3px 3px 0 rgba(0,0,0,0.5))',
                            }}
                        >
                            📜
                        </div>
                        <p
                            className="manga-subheading"
                            style={{
                                color: '#b0b0c0',
                                fontSize: '1.05rem',
                                marginBottom: '0.5rem',
                            }}
                        >
                            The scroll is sealed
                        </p>
                        <p
                            style={{
                                color: '#6a6a80',
                                fontSize: '0.85rem',
                                marginBottom: '1.5rem',
                                fontFamily: "'Outfit', sans-serif",
                            }}
                        >
                            Contains your session power. Click to unseal.
                        </p>
                        <button
                            className="btn-manga"
                            onClick={fetchToken}
                            disabled={loading}
                            style={{ padding: '14px 36px', fontSize: '1.15rem' }}
                        >
                            {loading ? (
                                <span
                                    style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: '10px',
                                    }}
                                >
                                    <span
                                        className="loader-spinner"
                                        style={{ width: '20px', height: '20px', borderWidth: '3px' }}
                                    ></span>
                                    Unsealing...
                                </span>
                            ) : (
                                '⚡ UNSEAL SCROLL!'
                            )}
                        </button>
                    </div>
                ) : (
                    /* Token Modal */
                    <div className="modal-overlay" onClick={() => setTokenData(null)}>
                        <div
                            className="modal-content"
                            onClick={(e) => e.stopPropagation()}
                            style={{ maxWidth: '600px' }}
                        >
                            {/* Modal Header */}
                            <div
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    marginBottom: '1.5rem',
                                }}
                            >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <span
                                        style={{
                                            fontSize: '1.8rem',
                                            filter: 'drop-shadow(2px 2px 0 rgba(0,0,0,0.5))',
                                        }}
                                    >
                                        📜
                                    </span>
                                    <div>
                                        <h2
                                            className="manga-subheading"
                                            style={{ fontSize: '1.3rem', color: '#fff' }}
                                        >
                                            JWT Scroll
                                        </h2>
                                        <span className="fx-text" style={{ fontSize: '0.6rem' }}>
                                            Active Session Power
                                        </span>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setTokenData(null)}
                                    style={{
                                        background: 'rgba(255, 45, 45, 0.1)',
                                        border: '2px solid rgba(255, 45, 45, 0.3)',
                                        color: '#ff4444',
                                        width: '36px',
                                        height: '36px',
                                        cursor: 'pointer',
                                        fontSize: '1.1rem',
                                        fontFamily: "'Bangers', cursive",
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        boxShadow: '2px 2px 0 rgba(0,0,0,0.3)',
                                        transition: 'all 0.2s ease',
                                    }}
                                    onMouseEnter={(e) => {
                                        e.target.style.background = 'rgba(255, 45, 45, 0.2)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.target.style.background = 'rgba(255, 45, 45, 0.1)';
                                    }}
                                >
                                    ✕
                                </button>
                            </div>

                            {/* Token Value */}
                            <div style={{ marginBottom: '1.25rem' }}>
                                <div
                                    style={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        marginBottom: '8px',
                                    }}
                                >
                                    <span className="fx-text" style={{ fontSize: '0.65rem' }}>
                                        Scroll Contents
                                    </span>
                                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                                        <MiniBtn
                                            onClick={() => setShowFull(!showFull)}
                                            color="#00e5ff"
                                        >
                                            {showFull ? '🔒 Mask' : '👁 Show'}
                                        </MiniBtn>
                                        <MiniBtn onClick={copyToken} color="#ffd700">
                                            📋 Copy
                                        </MiniBtn>
                                    </div>
                                </div>
                                <div className="token-text">
                                    {showFull ? tokenData.token : tokenData.maskedToken}
                                </div>
                            </div>

                            {/* Details Grid */}
                            <div
                                style={{
                                    display: 'grid',
                                    gridTemplateColumns: '1fr 1fr',
                                    gap: '1rem',
                                    background: 'rgba(255, 255, 255, 0.02)',
                                    padding: '1rem',
                                    border: '2px solid rgba(255, 45, 45, 0.1)',
                                }}
                            >
                                <TokenDetail label="Hero ID" value={tokenData.uid?.substring(0, 12) + '...'} />
                                <TokenDetail label="Seal Expires" value={formatDate(tokenData.expiry)} />
                                <TokenDetail label="Forged At" value={formatDate(tokenData.createdAt)} />
                                <TokenDetail label="Power Remaining" value={getTimeRemaining()} highlight />
                            </div>

                            {/* Footer */}
                            <div
                                style={{
                                    display: 'flex',
                                    gap: '0.75rem',
                                    marginTop: '1.5rem',
                                    justifyContent: 'flex-end',
                                }}
                            >
                                <button
                                    className="btn-manga-outline"
                                    onClick={fetchToken}
                                    style={{ padding: '10px 18px', fontSize: '0.9rem' }}
                                >
                                    ↻ Refresh
                                </button>
                                <button
                                    className="btn-manga"
                                    onClick={() => setTokenData(null)}
                                    style={{ padding: '10px 18px', fontSize: '0.9rem' }}
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Back */}
                <div
                    className="animate-fade-in-up delay-200"
                    style={{ textAlign: 'center', marginTop: '1.5rem' }}
                >
                    <button
                        className="btn-manga-outline"
                        onClick={() => navigate('/dashboard')}
                        style={{ padding: '10px 22px', fontSize: '0.95rem' }}
                    >
                        ← Back to HQ
                    </button>
                </div>
            </div>
        </div>
    );
};

const MiniBtn = ({ onClick, color, children }) => (
    <button
        onClick={onClick}
        style={{
            background: `${color}11`,
            border: `1px solid ${color}44`,
            color: color,
            padding: '3px 10px',
            cursor: 'pointer',
            fontSize: '0.7rem',
            fontWeight: '600',
            fontFamily: "'Outfit', sans-serif",
            letterSpacing: '0.03em',
            transition: 'all 0.2s ease',
        }}
    >
        {children}
    </button>
);

const TokenDetail = ({ label, value, highlight }) => (
    <div>
        <p className="fx-text" style={{ marginBottom: '3px', fontSize: '0.6rem' }}>
            {label}
        </p>
        <p
            style={{
                color: highlight ? '#ff2d2d' : '#d0d0e0',
                fontSize: '0.85rem',
                fontWeight: highlight ? '700' : '500',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                fontFamily: highlight ? "'Bangers', cursive" : "'Outfit', sans-serif",
                letterSpacing: highlight ? '0.05em' : '0',
            }}
        >
            {value}
        </p>
    </div>
);

export default TokenView;
