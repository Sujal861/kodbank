# 🏦 Kodbank — Secure Banking Web Application

A full-stack banking web application built with React, Node.js, Express, and MongoDB Atlas. Users can register, login, receive JWT tokens, and securely view their account balance.

![Tech Stack](https://img.shields.io/badge/React-19-blue?logo=react)
![Tech Stack](https://img.shields.io/badge/Node.js-Express-green?logo=node.js)
![Tech Stack](https://img.shields.io/badge/MongoDB-Atlas-brightgreen?logo=mongodb)
![Tech Stack](https://img.shields.io/badge/Auth-JWT-orange?logo=jsonwebtokens)

---

## 🚀 Features

- **User Registration** — Secure account creation with bcrypt password hashing
- **User Login** — JWT-based authentication with httpOnly cookie storage
- **Dashboard** — Beautiful glassmorphism UI with action cards
- **Balance View** — Animated glass card with confetti celebration
- **JWT Token View** — Secure modal with masked/full token toggle
- **Protected Routes** — JWT middleware with DB token verification and expiry checks
- **Responsive Design** — Mobile-first dark banking theme with smooth animations

---

## 📦 Tech Stack

| Layer       | Technology                        |
| ----------- | --------------------------------- |
| Frontend    | React 19 + Vite + TailwindCSS v4 |
| Backend     | Node.js + Express                 |
| Database    | MongoDB Atlas + Mongoose          |
| Auth        | JWT + bcrypt                      |
| State       | React Context API                 |
| Routing     | React Router v7                   |
| Cookies     | httpOnly JWT cookie               |
| UI          | Glassmorphism + Custom Animations |

---

## 📁 Project Structure

```
kodbank/
├── client/                     # React Frontend
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx      # Responsive navigation
│   │   │   ├── ProtectedRoute.jsx
│   │   │   └── Loader.jsx
│   │   ├── context/
│   │   │   └── AuthContext.jsx # Auth state management
│   │   ├── pages/
│   │   │   ├── Register.jsx
│   │   │   ├── Login.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Balance.jsx     # Animated balance card + confetti
│   │   │   └── TokenView.jsx   # Secure JWT modal
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css           # Design system
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── server/                     # Express Backend
│   ├── models/
│   │   ├── User.js             # User schema
│   │   └── Token.js            # Token persistence
│   ├── middleware/
│   │   └── auth.js             # JWT verification middleware
│   ├── routes/
│   │   ├── auth.js             # /register, /login, /logout
│   │   ├── balance.js          # /balance (protected)
│   │   └── token.js            # /token (protected)
│   ├── server.js
│   └── package.json
├── .env.example
└── README.md
```

---

## 🛠️ Setup & Installation

### Prerequisites
- Node.js 18+
- MongoDB Atlas account with a cluster

### 1. Clone & Install

```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 2. Configure Environment

Copy the `.env.example` to `server/.env` and fill in your MongoDB Atlas credentials:

```bash
cp .env.example server/.env
```

Edit `server/.env`:
```env
MONGO_URI=mongodb+srv://youruser:yourpassword@yourcluster.mongodb.net/kodbank
JWT_SECRET=your-super-secret-key-here
```

### 3. Run the Application

Open two terminals:

**Terminal 1 — Backend:**
```bash
cd server
npm run dev
```

**Terminal 2 — Frontend:**
```bash
cd client
npm run dev
```

The app will be available at: **http://localhost:5173**

---

## 📊 MongoDB Schema

### Users Collection
| Field    | Type   | Description              |
| -------- | ------ | ------------------------ |
| uid      | String | UUID v4 (unique)         |
| username | String | Unique, min 3 chars      |
| email    | String | Unique, validated format |
| password | String | bcrypt hashed            |
| balance  | Number | Default: 100,000         |
| phone    | String | Optional                 |
| role     | String | "Customer" only          |

### Tokens Collection
| Field  | Type   | Description            |
| ------ | ------ | ---------------------- |
| token  | String | JWT token string       |
| uid    | String | Reference to user      |
| expiry | Date   | TTL-indexed for auto   |

---

## 🔐 Security

- ✅ Passwords hashed with **bcrypt** (12 salt rounds)
- ✅ JWT tokens stored in **httpOnly cookies** (XSS protection)
- ✅ DB token comparison on every protected request
- ✅ Token expiry verification (JWT + DB level)
- ✅ Secrets stored in `.env` file (never hardcoded)
- ✅ CORS configured for specific origin
- ✅ Input validation on all endpoints

---

## 🎨 UI Highlights

- 🌑 Dark banking theme with subtle gradient backgrounds
- 🪟 Glassmorphism cards with backdrop blur
- ✨ Smooth CSS animations (fade-in, float, pulse-glow)
- 🎊 Confetti celebration on balance reveal
- 📱 Fully responsive with mobile hamburger menu
- 🔔 Styled toast notifications
- 💎 Premium typography with Inter & JetBrains Mono

---

## 📡 API Endpoints

| Method | Endpoint        | Auth     | Description          |
| ------ | --------------- | -------- | -------------------- |
| POST   | `/api/register` | Public   | Create new user      |
| POST   | `/api/login`    | Public   | Login & get JWT      |
| POST   | `/api/logout`   | Public   | Clear token & cookie |
| GET    | `/api/balance`  | Required | Get user balance     |
| GET    | `/api/token`    | Required | Get JWT token info   |
| GET    | `/api/health`   | Public   | Health check         |

---

## 📄 License

MIT License — Built with ❤️ for Kodbank
