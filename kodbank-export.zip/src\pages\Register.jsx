import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';

const Register = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        phone: '',
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match!');
            toast.error('Passwords do not match!');
            return;
        }

        if (formData.password.length < 6) {
            setError('Password must be at least 6 characters!');
            toast.error('Password must be at least 6 characters!');
            return;
        }

        setLoading(true);
        try {
            const res = await axios.post('/api/register', {
                username: formData.username,
                email: formData.email,
                password: formData.password,
                phone: formData.phone,
            });

            toast.success(res.data.message || 'Registration successful!');
            setTimeout(() => navigate('/login'), 1500);
        } catch (err) {
            const message =
                err.response?.data?.message ||
                (err.code === 'ERR_NETWORK'
                    ? 'Cannot connect to server. Make sure the backend is running!'
                    : 'Registration failed. Try again.');
            setError(message);
            toast.error(message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="page-container" style={{ justifyContent: 'center' }}>
            <div
                className="manga-panel animate-slam"
                style={{
                    maxWidth: '480px',
                    width: '100%',
                    padding: '2.5rem',
                }}
            >
                {/* Header */}
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <div
                        style={{
                            fontSize: '3rem',
                            marginBottom: '0.75rem',
                            filter: 'drop-shadow(3px 3px 0 rgba(0,0,0,0.5))',
                        }}
                    >
                        ⚔️
                    </div>
                    <h1
                        className="manga-heading"
                        style={{
                            fontSize: '2.2rem',
                            color: '#ffffff',
                            marginBottom: '0.5rem',
                        }}
                    >
                        Join the <span style={{ color: '#ff2d2d' }}>Guild</span>
                    </h1>
                    <p
                        style={{
                            color: '#6a6a80',
                            fontSize: '0.9rem',
                            fontFamily: "'Outfit', sans-serif",
                        }}
                    >
                        Create your Kodbank hero account
                    </p>
                </div>

                {/* Error Display */}
                {error && (
                    <div className="error-display">
                        ⚠️ {error}
                    </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '1.1rem' }}>
                        <label className="manga-label" htmlFor="register-username">
                            ★ Hero Name
                        </label>
                        <input
                            id="register-username"
                            className="manga-input"
                            type="text"
                            name="username"
                            placeholder="Choose your hero name..."
                            value={formData.username}
                            onChange={handleChange}
                            required
                            minLength={3}
                            autoComplete="username"
                        />
                    </div>

                    <div style={{ marginBottom: '1.1rem' }}>
                        <label className="manga-label" htmlFor="register-email">
                            ✉ Email
                        </label>
                        <input
                            id="register-email"
                            className="manga-input"
                            type="email"
                            name="email"
                            placeholder="hero@kodbank.com"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            autoComplete="email"
                        />
                    </div>

                    <div style={{ marginBottom: '1.1rem' }}>
                        <label className="manga-label" htmlFor="register-phone">
                            ☎ Phone{' '}
                            <span style={{ color: '#4a4a60', fontFamily: "'Outfit', sans-serif", fontSize: '0.75rem' }}>
                                (optional)
                            </span>
                        </label>
                        <input
                            id="register-phone"
                            className="manga-input"
                            type="tel"
                            name="phone"
                            placeholder="+91 98765 43210"
                            value={formData.phone}
                            onChange={handleChange}
                            autoComplete="tel"
                        />
                    </div>

                    <div style={{ marginBottom: '1.1rem' }}>
                        <label className="manga-label" htmlFor="register-password">
                            🔒 Secret Key
                        </label>
                        <input
                            id="register-password"
                            className="manga-input"
                            type="password"
                            name="password"
                            placeholder="Min. 6 characters..."
                            value={formData.password}
                            onChange={handleChange}
                            required
                            minLength={6}
                            autoComplete="new-password"
                        />
                    </div>

                    <div style={{ marginBottom: '1.5rem' }}>
                        <label className="manga-label" htmlFor="register-confirm-password">
                            🔒 Confirm Key
                        </label>
                        <input
                            id="register-confirm-password"
                            className="manga-input"
                            type="password"
                            name="confirmPassword"
                            placeholder="Re-enter secret key..."
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            required
                            autoComplete="new-password"
                        />
                    </div>

                    <button
                        type="submit"
                        className="btn-manga"
                        disabled={loading}
                        style={{
                            width: '100%',
                            padding: '16px',
                            fontSize: '1.2rem',
                        }}
                    >
                        {loading ? (
                            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                                <span
                                    className="loader-spinner"
                                    style={{ width: '20px', height: '20px', borderWidth: '3px' }}
                                ></span>
                                Activating...
                            </span>
                        ) : (
                            '⚡ Create Account!'
                        )}
                    </button>
                </form>

                {/* Footer */}
                <p
                    style={{
                        textAlign: 'center',
                        marginTop: '1.5rem',
                        color: '#6a6a80',
                        fontSize: '0.9rem',
                        fontFamily: "'Outfit', sans-serif",
                    }}
                >
                    Already a hero?{' '}
                    <Link
                        to="/login"
                        style={{
                            color: '#ff2d2d',
                            textDecoration: 'none',
                            fontWeight: '700',
                            fontFamily: "'Bangers', cursive",
                            letterSpacing: '0.05em',
                        }}
                    >
                        Sign In!
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default Register;
